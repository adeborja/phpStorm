<?php

/**
 * Created by PhpStorm.
 * User: adeborja
 * Date: 30/11/18
 * Time: 9:36
 */
namespace ConstantesDB;

class ConsLibroModel
{

    const TABLE_NAME = "libros";
    const ID = "id";
    const TITULO = "titulo";
    const PAGS = "numpag";
    const CAPITULOS = "capitulos";
}
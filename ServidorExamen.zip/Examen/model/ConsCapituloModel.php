<?php

/**
 * Created by PhpStorm.
 * User: adeborja
 * Date: 30/11/18
 * Time: 9:39
 */
namespace ConstantesDB;

class ConsCapituloModel
{
    const TABLE_NAME = "capitulos";
    const ID = "id";
    const IDLIBRO = "idLibro";
    const TITULO = "titulo";
    const PAGINAINICIO = "paginaInicio";
    const PAGINAFIN = "paginaFin";
}